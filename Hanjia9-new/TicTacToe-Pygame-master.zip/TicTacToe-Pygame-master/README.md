# TicTacToe-Pygame
A simple Tic Tac Toe game to have an overview around Python language and Pygame module!

## In-game images
![](inGame_images/menu.png)   ![](inGame_images/game.png)

## Using the application
- Clone GitHub repository
- Install Pygame: `pip install pygame`
- Run: `python main.py`
